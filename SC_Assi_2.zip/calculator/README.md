# calculator

Simple calculator written in Python w/ tkinter gui module.